//
//  ViewController.swift
//  wannaBuy
//
//  Created by Ziyao Wang on 7/1/15.
//  Copyright (c) 2015 Ziyao Wang. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var account: UITextField!

    @IBOutlet weak var password: UITextField!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib
        account.delegate = self;
        password.delegate = self;
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        if password.isFirstResponder() || account.isFirstResponder() {
            password.resignFirstResponder()
            account.resignFirstResponder()
        }
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        if textField == account{
            account.resignFirstResponder()
            password.becomeFirstResponder()
        }
        else if textField == password{
            password.resignFirstResponder()
        }
        return true
    }
    

    
    
    @IBAction func login(sender: UIButton)
    {
        
        
   
        
        
        
    }

    @IBOutlet weak var accountType: UITextField!
    @IBOutlet weak var passwordType: UIView!
}

